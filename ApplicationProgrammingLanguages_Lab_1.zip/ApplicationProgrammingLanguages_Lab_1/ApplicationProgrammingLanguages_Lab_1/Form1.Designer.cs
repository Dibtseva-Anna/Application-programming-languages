﻿
namespace ApplicationProgrammingLanguages_Lab_1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelDecision = new System.Windows.Forms.Label();
            this.checkBoxExtendCapabil = new System.Windows.Forms.CheckBox();
            this.radioButtonComplete = new System.Windows.Forms.RadioButton();
            this.radioButtonLimited = new System.Windows.Forms.RadioButton();
            this.groupBoxEnter = new System.Windows.Forms.GroupBox();
            this.textBoxPIN2 = new System.Windows.Forms.TextBox();
            this.label2PIN = new System.Windows.Forms.Label();
            this.textBoxPIN = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.labelPIN = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.buttonRegistration = new System.Windows.Forms.Button();
            this.groupBoxEnter.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelDecision
            // 
            this.labelDecision.AutoSize = true;
            this.labelDecision.Location = new System.Drawing.Point(43, 30);
            this.labelDecision.Name = "labelDecision";
            this.labelDecision.Size = new System.Drawing.Size(188, 17);
            this.labelDecision.TabIndex = 0;
            this.labelDecision.Text = "Выберите тип регистрации";
            // 
            // checkBoxExtendCapabil
            // 
            this.checkBoxExtendCapabil.AutoSize = true;
            this.checkBoxExtendCapabil.Location = new System.Drawing.Point(46, 86);
            this.checkBoxExtendCapabil.Name = "checkBoxExtendCapabil";
            this.checkBoxExtendCapabil.Size = new System.Drawing.Size(213, 21);
            this.checkBoxExtendCapabil.TabIndex = 1;
            this.checkBoxExtendCapabil.Text = "Расширенные возможности";
            this.checkBoxExtendCapabil.UseVisualStyleBackColor = true;
            this.checkBoxExtendCapabil.CheckedChanged += new System.EventHandler(this.checkBoxExtendCapabil_CheckedChanged);
            // 
            // radioButtonComplete
            // 
            this.radioButtonComplete.AutoSize = true;
            this.radioButtonComplete.Location = new System.Drawing.Point(369, 30);
            this.radioButtonComplete.Name = "radioButtonComplete";
            this.radioButtonComplete.Size = new System.Drawing.Size(79, 21);
            this.radioButtonComplete.TabIndex = 2;
            this.radioButtonComplete.TabStop = true;
            this.radioButtonComplete.Text = "Полная";
            this.radioButtonComplete.UseVisualStyleBackColor = true;
            this.radioButtonComplete.CheckedChanged += new System.EventHandler(this.radioButtonComplete_CheckedChanged);
            // 
            // radioButtonLimited
            // 
            this.radioButtonLimited.AutoSize = true;
            this.radioButtonLimited.Checked = true;
            this.radioButtonLimited.Location = new System.Drawing.Point(369, 86);
            this.radioButtonLimited.Name = "radioButtonLimited";
            this.radioButtonLimited.Size = new System.Drawing.Size(125, 21);
            this.radioButtonLimited.TabIndex = 3;
            this.radioButtonLimited.TabStop = true;
            this.radioButtonLimited.Text = "Ограниченная";
            this.radioButtonLimited.UseVisualStyleBackColor = true;
            this.radioButtonLimited.CheckedChanged += new System.EventHandler(this.radioButtonLimited_CheckedChanged);
            // 
            // groupBoxEnter
            // 
            this.groupBoxEnter.Controls.Add(this.textBoxPIN2);
            this.groupBoxEnter.Controls.Add(this.label2PIN);
            this.groupBoxEnter.Controls.Add(this.textBoxPIN);
            this.groupBoxEnter.Controls.Add(this.textBoxName);
            this.groupBoxEnter.Controls.Add(this.labelPIN);
            this.groupBoxEnter.Controls.Add(this.labelName);
            this.groupBoxEnter.Location = new System.Drawing.Point(31, 156);
            this.groupBoxEnter.Name = "groupBoxEnter";
            this.groupBoxEnter.Size = new System.Drawing.Size(463, 193);
            this.groupBoxEnter.TabIndex = 4;
            this.groupBoxEnter.TabStop = false;
            this.groupBoxEnter.Text = "Введите регистрационные данные";
            // 
            // textBoxPIN2
            // 
            this.textBoxPIN2.Location = new System.Drawing.Point(109, 124);
            this.textBoxPIN2.Name = "textBoxPIN2";
            this.textBoxPIN2.Size = new System.Drawing.Size(251, 22);
            this.textBoxPIN2.TabIndex = 5;
            this.textBoxPIN2.Visible = false;
            // 
            // label2PIN
            // 
            this.label2PIN.AutoSize = true;
            this.label2PIN.Location = new System.Drawing.Point(12, 124);
            this.label2PIN.Name = "label2PIN";
            this.label2PIN.Size = new System.Drawing.Size(38, 17);
            this.label2PIN.TabIndex = 4;
            this.label2PIN.Text = "PIN2";
            this.label2PIN.Visible = false;
            // 
            // textBoxPIN
            // 
            this.textBoxPIN.Location = new System.Drawing.Point(109, 84);
            this.textBoxPIN.Name = "textBoxPIN";
            this.textBoxPIN.Size = new System.Drawing.Size(251, 22);
            this.textBoxPIN.TabIndex = 3;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(109, 44);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(251, 22);
            this.textBoxName.TabIndex = 2;
            // 
            // labelPIN
            // 
            this.labelPIN.AutoSize = true;
            this.labelPIN.Location = new System.Drawing.Point(12, 89);
            this.labelPIN.Name = "labelPIN";
            this.labelPIN.Size = new System.Drawing.Size(30, 17);
            this.labelPIN.TabIndex = 1;
            this.labelPIN.Text = "PIN";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(12, 49);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(45, 17);
            this.labelName.TabIndex = 0;
            this.labelName.Text = "Name";
            // 
            // buttonRegistration
            // 
            this.buttonRegistration.Location = new System.Drawing.Point(214, 371);
            this.buttonRegistration.Name = "buttonRegistration";
            this.buttonRegistration.Size = new System.Drawing.Size(112, 23);
            this.buttonRegistration.TabIndex = 5;
            this.buttonRegistration.Text = "Регистрация";
            this.buttonRegistration.UseVisualStyleBackColor = true;
            this.buttonRegistration.Click += new System.EventHandler(this.buttonRegistration_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 416);
            this.Controls.Add(this.buttonRegistration);
            this.Controls.Add(this.groupBoxEnter);
            this.Controls.Add(this.radioButtonLimited);
            this.Controls.Add(this.radioButtonComplete);
            this.Controls.Add(this.checkBoxExtendCapabil);
            this.Controls.Add(this.labelDecision);
            this.Name = "Form1";
            this.Text = "Registration form";
            this.groupBoxEnter.ResumeLayout(false);
            this.groupBoxEnter.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelDecision;
        private System.Windows.Forms.CheckBox checkBoxExtendCapabil;
        private System.Windows.Forms.RadioButton radioButtonComplete;
        private System.Windows.Forms.RadioButton radioButtonLimited;
        private System.Windows.Forms.GroupBox groupBoxEnter;
        private System.Windows.Forms.TextBox textBoxPIN;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label labelPIN;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxPIN2;
        private System.Windows.Forms.Label label2PIN;
        private System.Windows.Forms.Button buttonRegistration;
    }
}

