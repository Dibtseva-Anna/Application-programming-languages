﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApplicationProgrammingLanguages_Lab_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButtonComplete_CheckedChanged(object sender, EventArgs e)
        {
            label2PIN.Visible = true;
            textBoxPIN2.Visible = true;
        }

        private void radioButtonLimited_CheckedChanged(object sender, EventArgs e)
        {
            label2PIN.Visible = false;
            textBoxPIN2.Visible = false;
        }

        private void checkBoxExtendCapabil_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonLimited.Checked == true) {
                if (checkBoxExtendCapabil.CheckState == CheckState.Checked) {
                    label2PIN.Visible = true;
                    textBoxPIN2.Visible = true;
                }
                else {
                    label2PIN.Visible = false;
                    textBoxPIN2.Visible = false;
                }
            }
        }

        private void buttonRegistration_Click(object sender, EventArgs e)
        {
            if (textBoxName.TextLength == 0 || textBoxPIN.TextLength == 0 ||
                (textBoxPIN2.Visible == true && textBoxPIN2.TextLength == 0))
                MessageBox.Show("You have not filled in some field!");
        }
    }
}
