﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SystemTray
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            showWindow();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                hideWindow();
            }
            else {
                showWindow();
            }
        }

        private void toolStripMenuItemShow_Click(object sender, EventArgs e)
        {
            showWindow();
        }

        private void toolStripMenuItemHide_Click(object sender, EventArgs e)
        {
            hideWindow();
        }

        private void showWindow()
        {
            this.ShowInTaskbar = true;
            this.WindowState = FormWindowState.Normal;
            toolStripMenuItemHide.Enabled = true;
            toolStripMenuItemShow.Enabled = false;
        }
        private void hideWindow()
        {
            this.ShowInTaskbar = false;
            this.WindowState = FormWindowState.Minimized;
            toolStripMenuItemHide.Enabled = false;
            toolStripMenuItemShow.Enabled = true;
        }
    }
}
