﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using ApplicationProgrammingLanguages_Lab_1;

namespace PaintSimple
{
    public partial class Form : System.Windows.Forms.Form
    {
        Pen pen;
        bool flag;
        ArrayList points = new ArrayList();

        public Form()
        {
            InitializeComponent();
            this.Cursor = new Cursor("PENCIL.CUR");
            pen = new Pen(this.ForeColor);
        }

        private void Form_MouseUp(object sender, MouseEventArgs e)
        {
            flag = false;
        }

        private void Form_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) {
                flag = true;
                points.Clear();
            }
        }

        private void Form_MouseMove(object sender, MouseEventArgs e)
        {
            if (flag) {
                Point pt = new Point(e.X, e.Y);
                points.Add(pt);
                if (points.Count <= 1)
                    return;
                Point[] ptArr = new Point[points.Count];
                points.CopyTo(ptArr, 0);
                Graphics gr = this.CreateGraphics();
                gr.DrawCurve(pen, ptArr);
            }
        }

        private void colourToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog.ShowDialog(this);
            pen.Color = colorDialog.Color;
        }

        private void lineThicknessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 formForSize = new Form2(pen);
            formForSize.ShowDialog(this);
        }
    }
}
