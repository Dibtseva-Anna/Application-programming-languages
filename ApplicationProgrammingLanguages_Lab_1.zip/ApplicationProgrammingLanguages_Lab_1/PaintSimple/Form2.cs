﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApplicationProgrammingLanguages_Lab_1
{
    public partial class Form2 : Form
    {
        Pen pen;

        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Pen cursor)
        {
            InitializeComponent();
            pen = cursor;
            sizePanel.BackColor = pen.Color;
            sizePanel.Height = (int)pen.Width;
            trackBar.Value = (int)pen.Width;
            numericUpDown.Value = (decimal)pen.Width;
        }

        private void trackBar_ValueChanged(object sender, EventArgs e)
        {
            numericUpDown.Value = trackBar.Value;
        }

        private void numericUpDown_ValueChanged(object sender, EventArgs e)
        {
            trackBar.Value = (int)numericUpDown.Value;
            sizePanel.Height = trackBar.Value;
            sizePanel.Location = new Point(sizePanel.Location.X,
                    (int)(65 - sizePanel.Height/ 2));
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            pen.Width = (float)numericUpDown.Value;
        }
    }
}
