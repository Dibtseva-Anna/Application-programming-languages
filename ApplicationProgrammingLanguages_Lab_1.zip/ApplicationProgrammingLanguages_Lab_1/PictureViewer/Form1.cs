﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;

namespace PictureViewer
{
    public partial class Form : System.Windows.Forms.Form
    {

        public Form()
        {
            InitializeComponent();
            pageSetupDialog.Document = new System.Drawing.Printing.PrintDocument();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                pictureBox.Image = Image.FromFile(openFileDialog.FileName);
            }
            //делаем доступными трипы вида
            enabledChange();

            //применяем к открытой картинке включенный вид
            if (alterSizeToolStripMenuItem.Checked)
                pictureSizeModeChange("alter size");
            else if (initialSizeToolStripMenuItem.Checked)
                pictureSizeModeChange("initial size");
            else if (toCenterToolStripMenuItem.Checked)
                pictureSizeModeChange("to center");
            else if (autoSizeToolStripMenuItem.Checked)
                pictureSizeModeChange("auto size");

            //Filling StatusStrip
            wayStripStatusLabel.Text = "Изображение" + openFileDialog.FileName;
            sizeStripStatusLabel.Text = pictureBox.Image.Width + " x " + pictureBox.Image.Height;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pictureBox.Image != null) {
                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    pictureBox.Image.Save(saveFileDialog.FileName);
                }
            }
        }

        private void pageSetupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pageSetupDialog.ShowDialog();
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog.Document = printDocument;
            if (pictureBox.Image != null) {
                printPreviewDialog.Document.PrintPage += PrintPage;
            }
            printPreviewDialog.ShowDialog();
        }
        private void PrintPage(object o, PrintPageEventArgs e)
        {
            Bitmap bitmap = new Bitmap(pictureBox.Image, pictureBox.Image.Width * 3, pictureBox.Image.Height * 3);
            e.Graphics.DrawImage((Image)bitmap, new Point(15, 15));
            e.Graphics.DrawString("Image size: " + bitmap.Size.ToString(),
                new Font(this.Font.Name, this.Font.Size * 3, this.Font.Style), Brushes.Black,
                new Point(20, bitmap.Height + 70));
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void alterSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureSizeModeChange("alter size");
        }

        private void initialSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureSizeModeChange("initial size");
        }

        private void toCenterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureSizeModeChange("to center");
        }

        private void autoSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureSizeModeChange("auto size");
        }

        private void checkedChange(ToolStripMenuItem item, Boolean val) {
            item.Checked = val;
        }

        private void enabledChange() {
            alterSizeToolStripMenuItem.Enabled = true;
            initialSizeToolStripMenuItem.Enabled = true;
            toCenterToolStripMenuItem.Enabled = true;
            autoSizeToolStripMenuItem.Enabled = true;
        }

        private void pictureSizeModeChange(string item) {
            switch(item){
                case "alter size":
                    pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                    if (alterSizeToolStripMenuItem.Checked != true)
                    {
                        checkedChange(alterSizeToolStripMenuItem, true);
                        checkedChange(initialSizeToolStripMenuItem, false);
                        checkedChange(toCenterToolStripMenuItem, false);
                        checkedChange(autoSizeToolStripMenuItem, false);
                    }
                    break;
                case "initial size":
                    pictureBox.SizeMode = PictureBoxSizeMode.Normal;
                    if (initialSizeToolStripMenuItem.Checked != true)
                    {
                        checkedChange(alterSizeToolStripMenuItem, false);
                        checkedChange(initialSizeToolStripMenuItem, true);
                        checkedChange(toCenterToolStripMenuItem, false);
                        checkedChange(autoSizeToolStripMenuItem, false);
                    }
                    break;
                case "to center":
                    pictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
                    if (toCenterToolStripMenuItem.Checked != true)
                    {
                        checkedChange(alterSizeToolStripMenuItem, false);
                        checkedChange(initialSizeToolStripMenuItem, false);
                        checkedChange(toCenterToolStripMenuItem, true);
                        checkedChange(autoSizeToolStripMenuItem, false);
                    }
                    break;
                case "auto size":
                    pictureBox.SizeMode = PictureBoxSizeMode.AutoSize;
                    if (autoSizeToolStripMenuItem.Checked != true)
                    {
                        checkedChange(alterSizeToolStripMenuItem, false);
                        checkedChange(initialSizeToolStripMenuItem, false);
                        checkedChange(toCenterToolStripMenuItem, false);
                        checkedChange(autoSizeToolStripMenuItem, true);
                    }
                    break;
            }
        }
    }
}
