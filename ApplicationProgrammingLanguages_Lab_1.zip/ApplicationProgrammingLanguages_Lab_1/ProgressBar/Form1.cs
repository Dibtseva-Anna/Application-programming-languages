﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ProgressBar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            
            try {
                progressBar.Value = int.Parse(textBox.Text);
            } catch {
                MessageBox.Show("При выполнении приобразования типов возникла ошибка");
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            for (int i = progressBar.Value + 1; i <= 100; i++) {
                progressBar.Value = i;
            }
            pictureBoxGif.Visible = true;
            pictureBoxGif.Enabled = true;
        }
    }
}
